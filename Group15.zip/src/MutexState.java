
public enum MutexState {
	HOLD, VOTE,RELEASE, REQUEST;
}
